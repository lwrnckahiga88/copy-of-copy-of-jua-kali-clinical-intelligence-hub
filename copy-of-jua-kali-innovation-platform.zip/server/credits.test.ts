import { describe, it, expect, beforeEach, vi, afterEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

/**
 * Mock database functions
 */
vi.mock("./db", () => ({
  getUserCredits: vi.fn(),
  deductCredits: vi.fn(),
  addCredits: vi.fn(),
  logAgentUsage: vi.fn(),
}));

function createAuthContext(userId: number = 1): TrpcContext {
  return {
    user: {
      id: userId,
      openId: `user-${userId}`,
      email: `user${userId}@example.com`,
      name: `User ${userId}`,
      loginMethod: "manus",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("Credits Router", () => {
  afterEach(() => {
    vi.clearAllMocks();
  });

  describe("credits.getBalance", () => {
    it("should return user's credit balance", async () => {
      const { getUserCredits } = await import("./db");
      vi.mocked(getUserCredits).mockResolvedValue({
        id: 1,
        userId: 1,
        balance: 100,
        totalSpent: 0,
        totalEarned: 100,
        createdAt: new Date(),
        updatedAt: new Date(),
      });

      const ctx = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      const balance = await caller.credits.getBalance();

      expect(balance).toBe(100);
      expect(getUserCredits).toHaveBeenCalledWith(1);
    });

    it("should return default 100 credits if user has no credit record", async () => {
      const { getUserCredits } = await import("./db");
      vi.mocked(getUserCredits).mockResolvedValue(null);

      const ctx = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      const balance = await caller.credits.getBalance();

      expect(balance).toBe(100);
    });
  });

  describe("credits.getDetails", () => {
    it("should return detailed credit information", async () => {
      const { getUserCredits } = await import("./db");
      const mockCredits = {
        id: 1,
        userId: 1,
        balance: 850,
        totalSpent: 150,
        totalEarned: 1000,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      vi.mocked(getUserCredits).mockResolvedValue(mockCredits);

      const ctx = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      const details = await caller.credits.getDetails();

      expect(details).toMatchObject({
        balance: 850,
        totalSpent: 150,
        totalEarned: 1000,
      });
    });
  });

  describe("credits.deductForAgent", () => {
    it("should successfully deduct credits for agent access", async () => {
      const { deductCredits, logAgentUsage, getUserCredits } = await import("./db");

      vi.mocked(deductCredits).mockResolvedValue(undefined);
      vi.mocked(logAgentUsage).mockResolvedValue(undefined);
      vi.mocked(getUserCredits).mockResolvedValue({
        id: 1,
        userId: 1,
        balance: 75,
        totalSpent: 25,
        totalEarned: 100,
        createdAt: new Date(),
        updatedAt: new Date(),
      });

      const ctx = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      const result = await caller.credits.deductForAgent({
        agentId: "agent-001",
        agentName: "Medical Diagnosis AI",
        creditsCost: 25,
      });

      expect(result.success).toBe(true);
      expect(result.remainingCredits).toBe(75);
      expect(deductCredits).toHaveBeenCalledWith(1, 25);
      expect(logAgentUsage).toHaveBeenCalledWith(
        1,
        "agent-001",
        "Medical Diagnosis AI",
        25
      );
    });

    it("should throw error if insufficient credits", async () => {
      const { deductCredits } = await import("./db");

      vi.mocked(deductCredits).mockRejectedValue(
        new Error("Insufficient credits")
      );

      const ctx = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      await expect(
        caller.credits.deductForAgent({
          agentId: "agent-001",
          agentName: "Medical Diagnosis AI",
          creditsCost: 200,
        })
      ).rejects.toThrow("Insufficient credits");
    });

    it("should validate credit cost is positive", async () => {
      const ctx = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      await expect(
        caller.credits.deductForAgent({
          agentId: "agent-001",
          agentName: "Medical Diagnosis AI",
          creditsCost: -10,
        })
      ).rejects.toThrow();
    });
  });
});

describe("Mpesa Router", () => {
  afterEach(() => {
    vi.clearAllMocks();
  });

  describe("mpesa.initiateSTKPush", () => {
    it("should initiate STK Push with valid phone number", async () => {
      const ctx = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      const result = await caller.mpesa.initiateSTKPush({
        phoneNumber: "254712345678",
        amount: 29,
        credits: 1000,
      });

      expect(result.success).toBe(true);
      expect(result.transactionId).toBeDefined();
      expect(result.phoneNumber).toBe("254712345678");
      expect(result.amount).toBe(29);
      expect(result.credits).toBe(1000);
      expect(result.message).toContain("STK Push initiated");
    });

    it("should reject invalid phone number format", async () => {
      const ctx = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      await expect(
        caller.mpesa.initiateSTKPush({
          phoneNumber: "invalid",
          amount: 29,
          credits: 1000,
        })
      ).rejects.toThrow();
    });

    it("should reject negative amount", async () => {
      const ctx = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      await expect(
        caller.mpesa.initiateSTKPush({
          phoneNumber: "254712345678",
          amount: -29,
          credits: 1000,
        })
      ).rejects.toThrow();
    });

    it("should support different payment tiers", async () => {
      const ctx = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      const tiers = [
        { amount: 5, credits: 100 },
        { amount: 29, credits: 1000 },
        { amount: 99, credits: 5000 },
      ];

      for (const tier of tiers) {
        const result = await caller.mpesa.initiateSTKPush({
          phoneNumber: "254712345678",
          amount: tier.amount,
          credits: tier.credits,
        });

        expect(result.success).toBe(true);
        expect(result.amount).toBe(tier.amount);
        expect(result.credits).toBe(tier.credits);
      }
    });
  });

  describe("mpesa.confirmPayment", () => {
    it("should add credits on successful payment", async () => {
      const { addCredits } = await import("./db");

      vi.mocked(addCredits).mockResolvedValue(undefined);

      const ctx = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      const result = await caller.mpesa.confirmPayment({
        transactionId: "TXN123456789",
        amount: 29,
        credits: 1000,
        status: "success",
      });

      expect(result.success).toBe(true);
      expect(result.creditsAdded).toBe(1000);
      expect(addCredits).toHaveBeenCalledWith(1, 1000);
    });

    it("should not add credits on failed payment", async () => {
      const { addCredits } = await import("./db");
      vi.mocked(addCredits).mockClear();

      const ctx = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      const result = await caller.mpesa.confirmPayment({
        transactionId: "TXN123456789",
        amount: 29,
        credits: 1000,
        status: "failed",
      });

      expect(result.success).toBe(false);
      expect(addCredits).not.toHaveBeenCalled();
    });

    it("should handle payment errors gracefully", async () => {
      const { addCredits } = await import("./db");

      vi.mocked(addCredits).mockRejectedValue(
        new Error("Database error")
      );

      const ctx = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      await expect(
        caller.mpesa.confirmPayment({
          transactionId: "TXN123456789",
          amount: 29,
          credits: 1000,
          status: "success",
        })
      ).rejects.toThrow();
    });
  });

  describe("mpesa.checkPaymentStatus", () => {
    it("should return payment status", async () => {
      const ctx = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      const result = await caller.mpesa.checkPaymentStatus({
        transactionId: "TXN123456789",
      });

      expect(result.status).toBeDefined();
      expect(result.transactionId).toBe("TXN123456789");
    });
  });
});

describe("Authentication Requirements", () => {
  afterEach(() => {
    vi.clearAllMocks();
  });

  it("should require authentication for credits routes", async () => {
    const ctx = {
      user: null,
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: {} as TrpcContext["res"],
    } as TrpcContext;

    const caller = appRouter.createCaller(ctx);

    await expect(caller.credits.getBalance()).rejects.toThrow();
  });

  it("should require authentication for mpesa routes", async () => {
    const ctx = {
      user: null,
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: {} as TrpcContext["res"],
    } as TrpcContext;

    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.mpesa.initiateSTKPush({
        phoneNumber: "254712345678",
        amount: 29,
        credits: 1000,
      })
    ).rejects.toThrow();
  });
});
