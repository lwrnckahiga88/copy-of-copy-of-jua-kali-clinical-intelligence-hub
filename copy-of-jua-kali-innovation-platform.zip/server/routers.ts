import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { getUserCredits, deductCredits, addCredits, logAgentUsage } from "./db";
import { z } from "zod";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  credits: router({
    /**
     * Get user's credit balance
     */
    getBalance: protectedProcedure.query(async ({ ctx }) => {
      const userCredits = await getUserCredits(ctx.user.id);
      return userCredits?.balance ?? 100;
    }),

    /**
     * Get detailed credit information
     */
    getDetails: protectedProcedure.query(async ({ ctx }) => {
      const userCredits = await getUserCredits(ctx.user.id);
      return userCredits || {
        balance: 100,
        totalSpent: 0,
        totalEarned: 100,
      };
    }),

    /**
     * Deduct credits for agent access
     */
    deductForAgent: protectedProcedure
      .input(z.object({
        agentId: z.string(),
        agentName: z.string(),
        creditsCost: z.number().positive(),
      }))
      .mutation(async ({ ctx, input }) => {
        try {
          await deductCredits(ctx.user.id, input.creditsCost);
          await logAgentUsage(ctx.user.id, input.agentId, input.agentName, input.creditsCost);
          const updatedCredits = await getUserCredits(ctx.user.id);
          return {
            success: true,
            remainingCredits: updatedCredits?.balance ?? 0,
          };
        } catch (error) {
          throw new Error(error instanceof Error ? error.message : "Failed to deduct credits");
        }
      }),
  }),

  mpesa: router({
    /**
     * Initiate STK Push for Mpesa payment
     */
    initiateSTKPush: protectedProcedure
      .input(z.object({
        phoneNumber: z.string().regex(/^\d{10,15}$/, "Invalid phone number"),
        amount: z.number().positive(),
        credits: z.number().positive(),
      }))
      .mutation(async ({ ctx, input }) => {
        try {
          // TODO: Implement actual Mpesa Daraja API call
          // For now, return mock response
          const transactionId = `TXN${Date.now()}`;
          
          return {
            success: true,
            transactionId,
            message: "STK Push initiated. Please enter your M-Pesa PIN",
            phoneNumber: input.phoneNumber,
            amount: input.amount,
            credits: input.credits,
          };
        } catch (error) {
          throw new Error("Failed to initiate payment");
        }
      }),

    /**
     * Check payment status
     */
    checkPaymentStatus: protectedProcedure
      .input(z.object({
        transactionId: z.string(),
      }))
      .query(async ({ input }) => {
        // TODO: Implement actual Mpesa Daraja API call
        return {
          status: "pending",
          transactionId: input.transactionId,
        };
      }),

    /**
     * Callback endpoint for Mpesa payment confirmation
     */
    confirmPayment: protectedProcedure
      .input(z.object({
        transactionId: z.string(),
        amount: z.number(),
        credits: z.number(),
        status: z.enum(["success", "failed"]),
      }))
      .mutation(async ({ ctx, input }) => {
        if (input.status === "success") {
          await addCredits(ctx.user.id, input.credits);
          return {
            success: true,
            message: "Credits added successfully",
            creditsAdded: input.credits,
          };
        }
        return {
          success: false,
          message: "Payment failed",
        };
      }),
  }),
});

export type AppRouter = typeof appRouter;
