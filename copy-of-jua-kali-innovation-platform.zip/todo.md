# Jua Kali Hub - Project TODO

## Phase 1: Project Setup & Design System
- [x] Create design system tokens in index.css (dark theme, colors, typography, spacing)
- [x] Set up global styling and Tailwind configuration
- [x] Create reusable component library structure

## Phase 2: Landing Page & Authentication
- [x] Build landing page with hero section
- [x] Create pricing page with three tiers (Free, Pro, Enterprise)
- [x] Implement Manus OAuth login flow
- [x] Create login redirect for unauthenticated users
- [x] Add logout functionality

## Phase 3: Dashboard Layout & Navigation
- [x] Create DashboardLayout component with sidebar
- [x] Build sidebar navigation with 55+ agent listing
- [x] Implement agent search functionality
- [x] Implement category filtering in sidebar
- [x] Create category grouping logic
- [x] Add credit balance display in dashboard header

## Phase 4: Agent System & iframe Loader
- [x] Create pageMapping.ts with all 55 agent configurations
- [x] Define agent properties: id, name, description, category, htmlFile, creditCost
- [x] Build agent iframe loader component
- [x] Implement agent loading from /agents/<filename> path
- [x] Create agent detail view in dashboard
- [x] Add agent information display (name, description, cost)

## Phase 5: Credit System
- [x] Create credits table in database schema
- [x] Add credit initialization (100 credits for new users)
- [x] Build credit deduction logic when opening agents
- [x] Create credit balance query endpoint
- [x] Build credit display component
- [x] Add insufficient credits warning

## Phase 6: Mpesa Integration
- [x] Create Mpesa configuration with Daraja API credentials
- [x] Build STK Push initiation endpoint
- [x] Create phone number input form
- [x] Implement payment callback handling
- [x] Add credit top-up logic after successful payment
- [x] Build "Top Up with Mpesa" button component
- [x] Add payment status notifications

## Phase 7: Service Worker & PWA
- [x] Create workbox-config.js for precaching
- [x] Register service worker in client
- [x] Precache all 55+ HTML agent modules
- [x] Implement offline-first caching strategy
- [x] Add service worker update notifications
- [x] Create manifest.json for PWA

## Phase 8: GitHub Actions & Deployment
- [x] Create .github/workflows/deploy.yml
- [x] Configure Workbox service worker generation step
- [x] Set up Railway deployment action
- [x] Add RAILWAY_TOKEN secret configuration
- [x] Create Dockerfile for Railway
- [x] Create railway.json configuration

## Phase 9: Testing & Refinement
- [x] Write vitest unit tests for credits router
- [x] Write vitest unit tests for Mpesa router
- [x] Test authentication requirements
- [x] Test credit deduction logic
- [x] Test payment flows
- [x] Test agent loading and iframe functionality
- [x] Create responsive design structure
- [x] Performance optimization via Vite bundling

## Phase 10: Final Delivery
- [x] Create deployment checkpoint
- [x] Verify all features working
- [x] Ready for Railway deployment
