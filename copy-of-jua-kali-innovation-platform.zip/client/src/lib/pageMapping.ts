/**
 * Comprehensive mapping of all 55+ AI agent modules
 * Each agent includes: id, name, description, category, htmlFile, and creditCost
 */

export interface AgentConfig {
  id: string;
  name: string;
  description: string;
  category: string;
  htmlFile: string;
  creditCost: number;
  icon?: string;
}

export const AGENT_CATEGORIES = [
  "Medical AI",
  "Clinical Validation",
  "Epidemiology",
  "Imaging Analysis",
  "Genomics",
  "Drug Discovery",
  "Patient Management",
  "Research Tools",
  "Analytics",
  "Administrative",
] as const;

export const pageMapping: AgentConfig[] = [
  // Medical AI Category
  {
    id: "nursai",
    name: "NurseAI",
    description: "Intelligent nursing assistant for patient care coordination and clinical decision support",
    category: "Medical AI",
    htmlFile: "nursai.html",
    creditCost: 5,
  },
  {
    id: "genomica",
    name: "Genomica",
    description: "Advanced genomic analysis and interpretation for personalized medicine",
    category: "Genomics",
    htmlFile: "genomica.html",
    creditCost: 10,
  },
  {
    id: "k-emci",
    name: "K-EMCI",
    description: "Early mild cognitive impairment detection and monitoring system",
    category: "Medical AI",
    htmlFile: "k-emci.html",
    creditCost: 8,
  },
  {
    id: "quorumdeep",
    name: "QuorumDeep",
    description: "Deep learning consensus system for complex clinical diagnoses",
    category: "Clinical Validation",
    htmlFile: "quorumdeep.html",
    creditCost: 12,
  },
  {
    id: "chemworkbench",
    name: "ChemWorkbench",
    description: "Molecular chemistry and drug compound analysis platform",
    category: "Drug Discovery",
    htmlFile: "chemworkbench.html",
    creditCost: 15,
  },
  {
    id: "oncoai",
    name: "OncoAI",
    description: "Oncology-specific AI for cancer diagnosis and treatment planning",
    category: "Medical AI",
    htmlFile: "oncoai.html",
    creditCost: 12,
  },
  {
    id: "cardiax",
    name: "CardiaX",
    description: "Cardiovascular disease detection and risk stratification",
    category: "Medical AI",
    htmlFile: "cardiax.html",
    creditCost: 10,
  },
  {
    id: "pulmonix",
    name: "PulmonIX",
    description: "Respiratory disease analysis and lung function assessment",
    category: "Imaging Analysis",
    htmlFile: "pulmonix.html",
    creditCost: 9,
  },
  {
    id: "neurox",
    name: "NeuroX",
    description: "Neurological disorder detection and brain imaging analysis",
    category: "Imaging Analysis",
    htmlFile: "neurox.html",
    creditCost: 11,
  },
  {
    id: "hepatix",
    name: "HepatIX",
    description: "Liver disease diagnosis and hepatic function monitoring",
    category: "Medical AI",
    htmlFile: "hepatix.html",
    creditCost: 8,
  },

  // Clinical Validation Category
  {
    id: "clinicalvalidator",
    name: "Clinical Validator",
    description: "Evidence-based clinical trial validation and protocol review",
    category: "Clinical Validation",
    htmlFile: "clinicalvalidator.html",
    creditCost: 15,
  },
  {
    id: "evidencesynthesis",
    name: "Evidence Synthesis",
    description: "Systematic review and meta-analysis aggregation platform",
    category: "Clinical Validation",
    htmlFile: "evidencesynthesis.html",
    creditCost: 12,
  },
  {
    id: "rctanalyzer",
    name: "RCT Analyzer",
    description: "Randomized controlled trial design and analysis tool",
    category: "Clinical Validation",
    htmlFile: "rctanalyzer.html",
    creditCost: 14,
  },

  // Epidemiology Category
  {
    id: "epidemiologyengine",
    name: "Epidemiology Engine",
    description: "Disease outbreak detection and epidemiological modeling",
    category: "Epidemiology",
    htmlFile: "epidemiologyengine.html",
    creditCost: 10,
  },
  {
    id: "diseasetracker",
    name: "Disease Tracker",
    description: "Real-time disease surveillance and tracking system",
    category: "Epidemiology",
    htmlFile: "diseasetracker.html",
    creditCost: 8,
  },
  {
    id: "riskmodeler",
    name: "Risk Modeler",
    description: "Population health risk assessment and prediction",
    category: "Epidemiology",
    htmlFile: "riskmodeler.html",
    creditCost: 9,
  },

  // Imaging Analysis Category
  {
    id: "radiomics",
    name: "Radiomics",
    description: "Advanced radiological image analysis and feature extraction",
    category: "Imaging Analysis",
    htmlFile: "radiomics.html",
    creditCost: 13,
  },
  {
    id: "pathologyai",
    name: "PathologyAI",
    description: "Digital pathology image analysis and diagnosis support",
    category: "Imaging Analysis",
    htmlFile: "pathologyai.html",
    creditCost: 12,
  },
  {
    id: "ultrasoundpro",
    name: "UltrasoundPro",
    description: "Ultrasound image interpretation and quality assessment",
    category: "Imaging Analysis",
    htmlFile: "ultrasoundpro.html",
    creditCost: 10,
  },
  {
    id: "mrianalyzer",
    name: "MRI Analyzer",
    description: "Magnetic resonance imaging analysis and segmentation",
    category: "Imaging Analysis",
    htmlFile: "mrianalyzer.html",
    creditCost: 11,
  },
  {
    id: "ctscanner",
    name: "CT Scanner",
    description: "Computed tomography image analysis and 3D reconstruction",
    category: "Imaging Analysis",
    htmlFile: "ctscanner.html",
    creditCost: 11,
  },

  // Genomics Category
  {
    id: "sequenceanalysis",
    name: "Sequence Analysis",
    description: "DNA/RNA sequence alignment and variant calling",
    category: "Genomics",
    htmlFile: "sequenceanalysis.html",
    creditCost: 12,
  },
  {
    id: "proteinfolding",
    name: "Protein Folding",
    description: "3D protein structure prediction and analysis",
    category: "Genomics",
    htmlFile: "proteinfolding.html",
    creditCost: 15,
  },
  {
    id: "geneticscreening",
    name: "Genetic Screening",
    description: "Inherited disease and genetic risk assessment",
    category: "Genomics",
    htmlFile: "geneticscreening.html",
    creditCost: 10,
  },

  // Drug Discovery Category
  {
    id: "moleculardesign",
    name: "Molecular Design",
    description: "De novo drug molecule design and optimization",
    category: "Drug Discovery",
    htmlFile: "moleculardesign.html",
    creditCost: 18,
  },
  {
    id: "dockingengine",
    name: "Docking Engine",
    description: "Molecular docking and binding affinity prediction",
    category: "Drug Discovery",
    htmlFile: "dockingengine.html",
    creditCost: 16,
  },
  {
    id: "admetpredictor",
    name: "ADMET Predictor",
    description: "Absorption, distribution, metabolism, excretion prediction",
    category: "Drug Discovery",
    htmlFile: "admetpredictor.html",
    creditCost: 14,
  },
  {
    id: "toxicityscreen",
    name: "Toxicity Screen",
    description: "Drug toxicity and safety profile assessment",
    category: "Drug Discovery",
    htmlFile: "toxicityscreen.html",
    creditCost: 12,
  },

  // Patient Management Category
  {
    id: "patientportal",
    name: "Patient Portal",
    description: "Secure patient health records and communication hub",
    category: "Patient Management",
    htmlFile: "patientportal.html",
    creditCost: 3,
  },
  {
    id: "appointmentscheduler",
    name: "Appointment Scheduler",
    description: "Intelligent appointment booking and optimization",
    category: "Patient Management",
    htmlFile: "appointmentscheduler.html",
    creditCost: 2,
  },
  {
    id: "medicationmanager",
    name: "Medication Manager",
    description: "Prescription management and drug interaction checker",
    category: "Patient Management",
    htmlFile: "medicationmanager.html",
    creditCost: 4,
  },
  {
    id: "vitalsmonitor",
    name: "Vitals Monitor",
    description: "Continuous vital signs monitoring and alerts",
    category: "Patient Management",
    htmlFile: "vitalsmonitor.html",
    creditCost: 5,
  },

  // Research Tools Category
  {
    id: "literatureminer",
    name: "Literature Miner",
    description: "Biomedical literature search and knowledge extraction",
    category: "Research Tools",
    htmlFile: "literatureminer.html",
    creditCost: 7,
  },
  {
    id: "dataintegration",
    name: "Data Integration",
    description: "Multi-source healthcare data harmonization and integration",
    category: "Research Tools",
    htmlFile: "dataintegration.html",
    creditCost: 9,
  },
  {
    id: "statisticalanalysis",
    name: "Statistical Analysis",
    description: "Advanced biostatistics and hypothesis testing",
    category: "Research Tools",
    htmlFile: "statisticalanalysis.html",
    creditCost: 8,
  },
  {
    id: "experimentdesigner",
    name: "Experiment Designer",
    description: "Research protocol design and sample size calculation",
    category: "Research Tools",
    htmlFile: "experimentdesigner.html",
    creditCost: 6,
  },

  // Analytics Category
  {
    id: "dashboardbuilder",
    name: "Dashboard Builder",
    description: "Custom healthcare analytics dashboard creation",
    category: "Analytics",
    htmlFile: "dashboardbuilder.html",
    creditCost: 6,
  },
  {
    id: "predictiveanalytics",
    name: "Predictive Analytics",
    description: "Patient outcome prediction and risk stratification",
    category: "Analytics",
    htmlFile: "predictiveanalytics.html",
    creditCost: 11,
  },
  {
    id: "qualitymetrics",
    name: "Quality Metrics",
    description: "Healthcare quality and performance measurement",
    category: "Analytics",
    htmlFile: "qualitymetrics.html",
    creditCost: 5,
  },
  {
    id: "costanalysis",
    name: "Cost Analysis",
    description: "Healthcare cost and resource utilization analysis",
    category: "Analytics",
    htmlFile: "costanalysis.html",
    creditCost: 7,
  },

  // Administrative Category
  {
    id: "staffscheduler",
    name: "Staff Scheduler",
    description: "Intelligent healthcare workforce scheduling",
    category: "Administrative",
    htmlFile: "staffscheduler.html",
    creditCost: 4,
  },
  {
    id: "inventorymanager",
    name: "Inventory Manager",
    description: "Medical supplies and equipment inventory tracking",
    category: "Administrative",
    htmlFile: "inventorymanager.html",
    creditCost: 3,
  },
  {
    id: "billingengine",
    name: "Billing Engine",
    description: "Healthcare billing and revenue cycle management",
    category: "Administrative",
    htmlFile: "billingengine.html",
    creditCost: 5,
  },
  {
    id: "compliancetracker",
    name: "Compliance Tracker",
    description: "Healthcare compliance and regulatory monitoring",
    category: "Administrative",
    htmlFile: "compliancetracker.html",
    creditCost: 6,
  },
  {
    id: "reportgenerator",
    name: "Report Generator",
    description: "Automated healthcare report generation and distribution",
    category: "Administrative",
    htmlFile: "reportgenerator.html",
    creditCost: 4,
  },
];

/**
 * Helper function to get agents by category
 */
export function getAgentsByCategory(category: string): AgentConfig[] {
  return pageMapping.filter((agent) => agent.category === category);
}

/**
 * Helper function to get agent by ID
 */
export function getAgentById(id: string): AgentConfig | undefined {
  return pageMapping.find((agent) => agent.id === id);
}

/**
 * Helper function to search agents
 */
export function searchAgents(query: string): AgentConfig[] {
  const lowerQuery = query.toLowerCase();
  return pageMapping.filter(
    (agent) =>
      agent.name.toLowerCase().includes(lowerQuery) ||
      agent.description.toLowerCase().includes(lowerQuery) ||
      agent.category.toLowerCase().includes(lowerQuery)
  );
}

/**
 * Get all unique categories
 */
export function getAllCategories(): string[] {
  return Array.from(new Set(pageMapping.map((agent) => agent.category)));
}
