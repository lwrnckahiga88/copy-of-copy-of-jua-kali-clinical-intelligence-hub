import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Zap, AlertCircle } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

interface AgentDetailPanelProps {
  agent: {
    id: string;
    name: string;
    description: string;
    category: string;
    creditCost: number;
  };
  currentCredits: number;
  onAgentOpen?: () => void;
}

export function AgentDetailPanel({
  agent,
  currentCredits,
  onAgentOpen,
}: AgentDetailPanelProps) {
  const deductCredits = trpc.credits.deductForAgent.useMutation();
  const hasEnoughCredits = currentCredits >= agent.creditCost;

  const handleOpenAgent = async () => {
    if (!hasEnoughCredits) {
      toast.error(`Insufficient credits. You need ${agent.creditCost} credits but only have ${currentCredits}`);
      return;
    }

    try {
      await deductCredits.mutateAsync({
        agentId: agent.id,
        agentName: agent.name,
        creditsCost: agent.creditCost,
      });
      
      toast.success(`${agent.creditCost} credits deducted. Agent loaded.`);
      onAgentOpen?.();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to open agent");
    }
  };

  return (
    <Card className="p-6 border-border/50 space-y-6">
      {/* Agent Header */}
      <div className="space-y-2">
        <div className="flex items-start justify-between">
          <div>
            <h2 className="text-2xl font-bold">{agent.name}</h2>
            <p className="text-sm text-muted-foreground mt-1">{agent.category}</p>
          </div>
          <div className="bg-accent/20 rounded-lg px-3 py-2 text-center">
            <div className="text-2xl font-bold text-accent">{agent.creditCost}</div>
            <div className="text-xs text-muted-foreground">credits</div>
          </div>
        </div>
      </div>

      {/* Description */}
      <div className="space-y-2">
        <h3 className="font-semibold text-sm">Description</h3>
        <p className="text-sm text-muted-foreground leading-relaxed">
          {agent.description}
        </p>
      </div>

      {/* Credit Status */}
      <div className="space-y-3">
        <h3 className="font-semibold text-sm">Your Credits</h3>
        <div className="bg-card border border-border/50 rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm text-muted-foreground">Available</span>
            <span className="text-2xl font-bold text-accent">{currentCredits}</span>
          </div>
          <div className="w-full bg-muted rounded-full h-2">
            <div
              className="bg-accent rounded-full h-2 transition-all duration-300"
              style={{
                width: `${Math.min((currentCredits / (agent.creditCost * 2)) * 100, 100)}%`,
              }}
            />
          </div>
        </div>
      </div>

      {/* Warning or Action */}
      {!hasEnoughCredits ? (
        <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p className="font-semibold text-sm text-red-500">Insufficient Credits</p>
            <p className="text-sm text-red-500/80">
              You need {agent.creditCost} credits but only have {currentCredits}. 
              Top up your account to access this agent.
            </p>
          </div>
        </div>
      ) : (
        <div className="bg-accent/10 border border-accent/30 rounded-lg p-4">
          <p className="text-sm text-muted-foreground">
            Opening this agent will deduct <span className="font-semibold text-accent">{agent.creditCost} credits</span> from your account.
          </p>
        </div>
      )}

      {/* Action Button */}
      <Button
        className={`w-full ${
          hasEnoughCredits
            ? "bg-accent hover:bg-accent/90 text-accent-foreground"
            : "bg-muted text-muted-foreground cursor-not-allowed"
        }`}
        onClick={handleOpenAgent}
        disabled={!hasEnoughCredits || deductCredits.isPending}
      >
        {deductCredits.isPending ? (
          <>
            <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-current mr-2" />
            Loading...
          </>
        ) : (
          <>
            <Zap className="w-4 h-4 mr-2" />
            {hasEnoughCredits ? "Open Agent" : "Insufficient Credits"}
          </>
        )}
      </Button>
    </Card>
  );
}
